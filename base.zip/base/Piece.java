package base;

public abstract class Piece {
	public Piece() {
	}
	

}

package base;

public class Cheval extends Piece {
	private final int ID_CEHVAL = 4;
	public Cheval() {
		
	}
	public int getID_CEHVAL() {
		return ID_CEHVAL;
	}
}

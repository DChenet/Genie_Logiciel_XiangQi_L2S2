package base;

public class Canon extends Piece {
	private final int ID_CANON = 5;
	public Canon() {
		
	}
	public int getID_CANON() {
		return ID_CANON;
	}
}

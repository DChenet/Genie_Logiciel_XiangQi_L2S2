package base;

public class General extends Piece {
	private final int ID_GENERAL = 7; 

	public General() {
		
	}

	public int getID_GENERAL() {
		return ID_GENERAL;
	}
}

package base;

public class Soldat extends Piece {
	private final int ID_SOLDAT = 1;
	public Soldat() {
		
	}
	public int getID_SOLDAT() {
		return ID_SOLDAT;
	}
}

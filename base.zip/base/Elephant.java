package base;

public class Elephant extends Piece {
	private final int ID_ELEPHANT = 2;
	public Elephant() {
		
	}
	public int getID_ELEPHANT() {
		return ID_ELEPHANT;
	}
}

package base;

public class Garde extends Piece {
	private final int ID_GARDE = 3;
	public Garde() {
			
	}
	public int getID_GARDE() {
		return ID_GARDE;
	}
}

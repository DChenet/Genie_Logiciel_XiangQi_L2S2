package base;

public class Tour extends Piece {
	private final int ID_TOUR = 6;
	public Tour() {
		
	}
	public int getID_TOUR() {
		return ID_TOUR;
	}
}

package grounds;

public class Ice extends Ground {

	private static final int GROUND_ID = 2;
	
	public Ice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static int getGroundId() {
		return GROUND_ID;
	}
}

package grounds;

public class Plain extends Ground {

	private static final int GROUND_ID = 0;

	public Plain() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static int getGroundId() {
		return GROUND_ID;
	}

}

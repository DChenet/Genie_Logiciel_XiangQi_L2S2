package grounds;

public class Ground {

	private static final int GROUND_ID = 0;

	public Ground() {
		// TODO Auto-generated constructor stub
	}

	public static int getGroundId() {
		return GROUND_ID;
	}

}

package grounds;

public class Sand extends Ground {

	private static final int GROUND_ID = 1;

	public Sand() {
		// TODO Auto-generated constructor stub
		super();
	}

	public static int getGroundId() {
		return GROUND_ID;
	}

}

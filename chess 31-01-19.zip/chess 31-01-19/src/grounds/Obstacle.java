package grounds;

public class Obstacle extends Ground {

	private static final int GROUND_ID = -1;

	public Obstacle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static int getGroundId() {
		return GROUND_ID;
	}

}

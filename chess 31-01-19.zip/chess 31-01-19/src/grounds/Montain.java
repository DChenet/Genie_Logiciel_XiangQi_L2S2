package grounds;

public class Montain extends Ground {

	private static final int GROUND_ID = 3;

	public Montain() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static int getGroundId() {
		return GROUND_ID;
	}

}

package board;

import grounds.Ground;
import pieces.Advisor;
import pieces.Cannon;
import pieces.Chariot;
import pieces.Elephant;
import pieces.General;
import pieces.Horse;
import pieces.Piece;
import pieces.Soldier;

public class Board {

	private static final int WIDTH = 9;
	private static final int HEIGHT = 10;

	private Ground[][] environement = new Ground[WIDTH][HEIGHT];
	private Piece[][] board = new Piece[WIDTH][HEIGHT];

	public Board() {
		// TODO Auto-generated constructor stub
	}

	public void initDefault() {
		// Black side, plays first
		board[0][0] = new Chariot(0, 0, true);
		board[1][0] = new Horse(1, 0, true);
		board[2][0] = new Elephant(2, 0, true);
		board[3][0] = new Advisor(3, 0, true);
		board[4][0] = new General(4, 0, true);
		board[5][0] = new Advisor(5, 0, true);
		board[6][0] = new Elephant(6, 0, true);
		board[7][0] = new Horse(7, 0, true);
		board[8][0] = new Chariot(8, 0, true);

		board[1][2] = new Cannon(1, 2, true);
		board[7][2] = new Cannon(7, 2, true);

		board[0][3] = new Soldier(0, 3, true);
		board[2][3] = new Soldier(2, 4, true);
		board[4][3] = new Soldier(4, 5, true);
		board[6][3] = new Soldier(6, 6, true);
		board[8][3] = new Soldier(8, 7, true);

		// Red side, plays second
		board[0][9] = new Chariot(0, 9, false);
		board[1][9] = new Horse(1, 9, false);
		board[2][9] = new Elephant(2, 9, false);
		board[3][9] = new Advisor(3, 9, false);
		board[4][9] = new General(4, 9, false);
		board[5][9] = new Advisor(5, 9, false);
		board[6][9] = new Elephant(6, 9, false);
		board[7][9] = new Horse(7, 9, false);
		board[8][9] = new Chariot(8, 9, false);

		board[1][8] = new Cannon(1, 8, false);
		board[7][8] = new Cannon(7, 8, false);

		board[0][7] = new Soldier(0, 7, false);
		board[2][7] = new Soldier(2, 7, false);
		board[4][7] = new Soldier(4, 7, false);
		board[6][7] = new Soldier(6, 7, false);
		board[8][7] = new Soldier(8, 7, false);

	}

	public Ground[][] getEnvironement() {
		return environement;
	}

	public void setEnvironement(Ground[][] environement) {
		this.environement = environement;
	}

	public Piece[][] getBoard() {
		return board;
	}

	public void setBoard(Piece[][] board) {
		this.board = board;
	}

	public static int getWidth() {
		return WIDTH;
	}

	public static int getHeight() {
		return HEIGHT;
	}

}
